#!/bin/bash

# Set the protein and ligand filenames without extensions
PROTEIN="protein"
LIGAND="ligand"

# Download the protein PDB file and separate it into protein and ligand parts
grep 'ATOM  ' complex.pdb > ${PROTEIN}Only.pdb
grep 'HETATM' ${PROTEIN}.pdb > ${LIGAND}.pdb

# Process protein with pdb2gmx
gmx pdb2gmx -ff amber99sb -f ${PROTEIN}Only.pdb -o ${PROTEIN}_processed.pdb -p ${PROTEIN}.top -water spce -ignh

# Define the box and solvate
gmx editconf -f ${PROTEIN}Only.pdb -o Complex_box.pdb -d 1.0 -bt cubic
gmx solvate -cp Complex_box.pdb -cs spc216.gro -o Complex_solv.pdb -p Complex.top

# Add ions
gmx grompp -f ions.mdp -c Complex_solv.pdb -p Complex.top -o ions.tpr -maxwarn 7
echo "SOL" | gmx genion -s ions.tpr -o Complex_solv_ions.pdb -p Complex.top -pname NA -nname CL -neutral

# Energy minimization
gmx grompp -f em.mdp -c Complex_solv_ions.pdb -p Complex.top -o em.tpr
gmx mdrun -v -deffnm em

# Equilibration and production MD
# NVT Equilibration
gmx grompp -f nvt.mdp -c em.gro -p Complex.top -o nvt.tpr
gmx mdrun -v -deffnm nvt

# NPT Equilibration
gmx grompp -f npt.mdp -c nvt.gro -p Complex.top -o npt.tpr
gmx mdrun -v -deffnm npt

# Production MD
gmx grompp -f md.mdp -c npt.gro -p Complex.top -o md_0_1.tpr
gmx mdrun -v -deffnm md_0_1

# Post-processing and analysis can be added here

# End of the script
